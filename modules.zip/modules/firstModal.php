<?php
// firstModal
?>

<div class="modal fade" id="fistModal" tabindex="-1" aria-labelledby="fistModalLabel" aria-hidden="true">
  <div class="modal-dialog  modal-xl">

    <div class="modalbox">
      <button type="button" class="btn-close-modal" data-bs-dismiss="modal" aria-label="Fechar">
        <i class="fas fa-times"></i>
      </button>
      <img class="coverModal" src="<?php echo resizeImage(baseUrl() . '/assets/images/modal.jpg', 898, 264); ?>" alt="EGESTAS TORTOR VULPUTATE" title="EGESTAS TORTOR VULPUTATE">
      <div class="modalcont">
        <h2>EGESTAS TORTOR VULPUTATE</h2>
        <p class="text-secondary">Aenean eu leo quam. Pellentesque omare sem lacinia quam venenatis vestibulum. Donec ullamcorper nulla non metus auctor fringilla. Donec sed odio dui. Cras</p>
        <div class="pt-3">
          <a href="#" class="btnmodal">INSCREVA-SE</a>
        </div>
      </div>
    </div>

  </div>
</div>

<button type="button" id="modalCaller" class="btn btn-primary d-none" data-bs-toggle="modal" data-bs-target="#fistModal">
  
</button>

<script>
  document.addEventListener('DOMContentLoaded', function() {
    var modalShown = localStorage.getItem('modalShown');

    if (!modalShown) {
        document.getElementById("modalCaller").click();
        localStorage.setItem('modalShown', 'true');
    }
});

</script>