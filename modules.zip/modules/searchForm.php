<?php
// searchForm
?>
<form action="<?php echo baseUrl(); ?>search/1" method="get">
                        <div class="search-group">

                            <input placeholder="Pesquisar Cursos..." title="Pesquisar Cursos" type="search" class="form-control" name="s" />

                            <button type="submit" title="Pesquisar Cursos" class="btn">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </form>